*=========================================
* VISIT THE MARIO PARTY NETPLAY DISCORD!
*
* https://discord.gg/Qk4gUMa
*=========================================

== Mario Party 3: Costume Party v1.1 ==
By: Celery

Use xdelta3 or patch.bat (Windows only) to apply this patch to a clean 
Mario Party 3 (USA).z64 ROM.

== Usage ==

When choosing your character (original 6 only), hold one of the 
following buttons while pressing A:

C-Left:		Western Land
C-Up:		Pirate Land
C-Right:	Space Land
C-Down:		Horror Land
R:		Mystery Land

== Notes ==

- Costumes reset upon returning to the main menu.

- To choose skins for a CPU player, select the skin as a player,
	back out, choose your own character with no input, then back
	out again and choose your character with the skin.

- This mod doesn't fully work for Duel Mode boards yet, though it 
	will work for Mini-Games in Duel Mode.

== Changes ==

v1.1:	Bugfix to fix crashing on some models.

Thanks to gamemasterplc and PartyPlanner64 for being big helps.